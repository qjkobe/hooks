/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef JINTELLITYPE_PRIVATE_H
#define JINTELLITYPE_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.0.0.465"
#define VER_MAJOR	1
#define VER_MINOR	0
#define VER_RELEASE	0
#define VER_BUILD	465
#define COMPANY_NAME	"Melloware Inc (www.melloware.com)"
#define FILE_VERSION	"1.0"
#define FILE_DESCRIPTION	"Java JNI bridge to MS Intellitype commands"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	"Copyright 2006 Melloware Inc"
#define LEGAL_TRADEMARKS	"Copyright 2006 Melloware Inc"
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"JIntellitype"
#define PRODUCT_VERSION	"1.0"

#endif /*JINTELLITYPE_PRIVATE_H*/
